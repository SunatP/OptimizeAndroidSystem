Read carefully as this can be confusing. Focus on file sizes to avoid mixing them up during renaming.

Place desired v4a driver in: /system/lib/soundfx/
Rename the new v4a driver to: libv4a_fx_ics.so
Rename the original driver as the base name of newly added driver
Set v4a driver permissions to: 0644

Example of libv4a_fx_jb_NEON_SQ.so when done:

/system/lib/soundfx/libv4a_fx_ics.so (new driver) 0644
/system/lib/soundfx/libv4a_fx_jb.so (original driver) 0644

Reboot
