Place desired v4a driver in: /system/lib/soundfx/
Rename the v4a driver to: libv4a_fx_ics.so
Set v4a driver permissions to: 0644

Reboot
